const product = {
    zh: {
        select: [
            { value: 1, name: '比特币挖矿', disabled: false },
            { value: 2, name: '以太坊挖矿', disabled: false },
            { value: 3, name: 'SS币挖矿', disabled: true },
            { value: 4, name: 'BB币挖矿', disabled: true },
        ],
        product: {
            1: {
                goods: [
                    { title: '黄金级', title2: '入门', stock_tips: '有货（优惠中）', price_symbol: '￥', price_int: '88', price_decimal: '00', power: 3, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费<br/>零维护费<br/>零维护费<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: '白金级', title2: '推荐', stock_tips: '有货（优惠中）', price_symbol: '￥', price_int: '888', price_decimal: '00', power: 20, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: '钻石级', title2: '专业', stock_tips: '无货（更新中）', price_symbol: '￥', price_int: '8,888', price_decimal: '00', power: 50, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: '自定义计划', title2: '创建自定义比特币挖矿计划', stock_tips: '有货（优惠中）', price_symbol: '￥', price_int: '18,888', price_decimal: '00', power: 3, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: true, number: 0, slider_min: 0, slider_max: 100, unit_price: 10.65 },
                ]
            },
            2: {
                goods: [
                    { title: '2黄金级', title2: '2入门', stock_tips: '有货（优惠中）', price_symbol: '￥', price_int: '66', price_decimal: '00', power: 3, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费<br/>零维护费<br/>零维护费<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: '2白金级', title2: '2推荐', stock_tips: '有货（优惠中）', price_symbol: '￥', price_int: '666', price_decimal: '00', power: 20, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: '2钻石级', title2: '2专业', stock_tips: '无货（更新中）', price_symbol: '￥', price_int: '6,666', price_decimal: '00', power: 50, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: '2自定义计划', title2: '2创建自定义比特币挖矿计划', stock_tips: '有货（优惠中）', price_symbol: '￥', price_int: '18,888', price_decimal: '00', power: 3, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: true, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                ]
            }
        }
    },
    en: {
        select: [
            { value: 1, name: 'BTC', disabled: false },
            { value: 2, name: 'ETC', disabled: false },
            { value: 3, name: 'SS', disabled: true },
            { value: 4, name: 'BB', disabled: true },
        ],
        product: {
            1: {
                goods: [
                    { title: 'Gold', title2: 'Basics', stock_tips: 'In stock(Discount)', price_symbol: '$', price_int: '88', price_decimal: '00', power: 3, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费<br/>零维护费<br/>零维护费<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: 'Platinum', title2: 'Recommend', stock_tips: 'In stock(Discount)', price_symbol: '$', price_int: '888', price_decimal: '00', power: 20, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: 'Diamonds', title2: 'Pro', stock_tips: 'No stock(Discount)', price_symbol: '$', price_int: '8,888', price_decimal: '00', power: 50, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: 'Custom', title2: 'Customization', stock_tips: 'In stock(Discount)', price_symbol: '$', price_int: '18,888', price_decimal: '00', power: 3, power_symbol: 'TH', power_symbol_unit: 's', duration_tips: '24个月的Bitcoin挖矿', tips_html: 'xxxxxxxx挖矿算法<br/>零维护费', btn_txt: '购买计划', is_diy: true, number: 0, slider_min: 0, slider_max: 100, unit_price: 10.65 },
                ]
            },
            2: {
                goods: [
                    { title: 'Gold', title2: 'Basics', stock_tips: 'In stock(Discount)', price_symbol: '$', price_int: '88', price_decimal: '00', power: 3, power_symbol: 'MH', power_symbol_unit: 's', duration_tips: '24 month', tips_html: 'Happy Tree Friends<br/>Free maintenance fee', btn_txt: 'Buy', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: 'Platinum', title2: 'Recommend', stock_tips: 'In stock(Discount)', price_symbol: '$', price_int: '888', price_decimal: '00', power: 20, power_symbol: 'MH', power_symbol_unit: 's', duration_tips: '24 month', tips_html: 'Happy Tree Friends<br/>Free maintenance fee', btn_txt: 'Buy', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: 'Diamonds', title2: 'Pro', stock_tips: 'No stock(Discount)', price_symbol: '$', price_int: '8,888', price_decimal: '00', power: 50, power_symbol: 'MH', power_symbol_unit: 's', duration_tips: '24 month', tips_html: 'Happy Tree Friends<br/>Free maintenance fee', btn_txt: 'Buy', is_diy: false, number: 0, slider_min: 0, slider_max: 300, unit_price: 10 },
                    { title: 'Custom', title2: 'Customization', stock_tips: 'In stock(Discount)', price_symbol: '$', price_int: '18,888', price_decimal: '00', power: 3, power_symbol: 'MH', power_symbol_unit: 's', duration_tips: '24 month', tips_html: 'Happy Tree Friends<br/>Free maintenance fee', btn_txt: 'Buy', is_diy: true, number: 0, slider_min: 0, slider_max: 100, unit_price: 10.65 },
                ]
            }
        }
    },
}

// export default product